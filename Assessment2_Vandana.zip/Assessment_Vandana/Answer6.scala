import scala.io.StdIn._
object Answer6{
	def main(args: Array[String])
	{
		 val Moviename = readLine("What is your favorite movie of all times?")
		 println(Moviename+" is totally awesome!")
		}
}
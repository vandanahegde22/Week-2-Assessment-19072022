object Answer4{
	def main(args: Array[String])
	{
		val inputstr = "http://www.google.com"
		val charToFind = inputstr.charAt(7)
		println(s"The 8th character literal in $inputstr = $charToFind")
	}
}
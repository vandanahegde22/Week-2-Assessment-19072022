object Answer5{
	def main(args: Array[String])
	{
		val unitPrice = 2.50
		val qtyPurchased = 10
		val totalCost = qtyPurchased * unitPrice

		println(f"""Total cost of $qtyPurchased Glazed Donut ${if (qtyPurchased > 1) "s" else ""} = $$$totalCost%1.2f""")
	}
}
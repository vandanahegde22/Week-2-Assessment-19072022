object Answer2{
	def main(args: Array[String])
	{
		val dName = "Vanilla Donut"
	    val qPurchased = 10
	    val price = 2.50
	    val output =
		s"""
		   |{
		   |"donut_name":"$dName",
		   |"quantity_purchased":"$qPurchased",
		   |"price":$price
		   |}
		  """.stripMargin
  println(output)
	}
}